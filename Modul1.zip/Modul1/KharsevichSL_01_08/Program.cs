﻿namespace KharsevichSL_01_08
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Parent OneCar = new Parent(223.1,1400);
            Subsidiary TwoCar = new Subsidiary(113.0, 1100,5);

            OneCar.DisplayInfo();
            TwoCar.DisplayInfo();
        }
    }
}
