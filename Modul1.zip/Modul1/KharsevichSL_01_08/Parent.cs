﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KharsevichSL_01_08
{
    public class Parent
    {
        public double Mileage { get; set; }
        public double Consumption { get; set; }

        public Parent(double mileage, double consumption)
        {
            this.Mileage = mileage;
            this.Consumption = consumption;
        }
        public virtual double Quality()
        {
            return Mileage/Consumption;
        }
        public void DisplayInfo()
        {
            Console.WriteLine("Пробег: " + Mileage);
            Console.WriteLine("Расход на км.: " + Consumption);
            Console.WriteLine("Качество: " + Quality());
        }
    }
}
