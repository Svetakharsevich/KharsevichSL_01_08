﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KharsevichSL_01_08
{
    public class Subsidiary : Parent
    {
        public int P;
        public Subsidiary(double mileage, double consumption, int p) : base(mileage, consumption)
        {
            P = p;  
        }
        public override double Quality()
        {
            if (P < 5)
            {
                return base.Quality() * 1.15 * P;
            }
            else 
            {
                return base.Quality() * 1.7 * P;
            }
        }
    }
}
